
  # Design Broker Dashboard

  This is a code bundle for Design Broker Dashboard. The original project is available at https://www.figma.com/design/AQyJ2xTlEb3RpyLdFfvEcm/Design-Broker-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  