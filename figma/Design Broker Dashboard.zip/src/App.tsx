import { BrokerDashboard } from './components/BrokerDashboard';

export default function App() {
  return <BrokerDashboard />;
}
